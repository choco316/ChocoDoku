/**
 * ChocoDoku - solver.js
 * Motor de resolución, comprobación de unicidad y backtracking para Sudoku 9x9.
 */

import { normalizeBoard, boardStringToMatrix } from './utils.js';

/**
 * Resuelve un tablero de Sudoku y determina si tiene solución única, cero o múltiples soluciones.
 * @param {string|Array} boardInput - Tablero inicial.
 * @returns {Object} { solutionsCount: number, solution: string|null, hasUniqueSolution: boolean }
 */
export function solveSudoku(boardInput) {
    let boardStr;
    try {
        boardStr = normalizeBoard(boardInput);
    } catch (e) {
        return { solutionsCount: 0, solution: null, hasUniqueSolution: false, error: e.message };
    }

    const grid = boardStringToMatrix(boardStr).map(row => row.map(cell => parseInt(cell, 10)));
    let solutions = [];

    function isValid(g, row, col, num) {
        for (let i = 0; i < 9; i++) {
            if (g[row][i] === num && i !== col) return false;
            if (g[i][col] === num && i !== row) return false;
        }
        const startRow = Math.floor(row / 3) * 3;
        const startCol = Math.floor(col / 3) * 3;
        for (let r = 0; r < 3; r++) {
            for (let c = 0; c < 3; c++) {
                const currR = startRow + r;
                const currC = startCol + c;
                if (g[currR][currC] === num && (currR !== row || currC !== col)) return false;
            }
        }
        return true;
    }

    function findEmpty(g) {
        for (let r = 0; r < 9; r++) {
            for (let c = 0; c < 9; c++) {
                if (g[r][c] === 0) return [r, c];
            }
        }
        return null;
    }

    function backtrack(g) {
        // Si ya encontramos 2 soluciones, podemos detenernos (queremos probar unicidad: >1)
        if (solutions.length >= 2) return;

        const emptySpot = findEmpty(g);
        if (!emptySpot) {
            // Solución encontrada
            solutions.push(g.map(row => row.join('')).join(''));
            return;
        }

        const [row, col] = emptySpot;
        for (let num = 1; num <= 9; num++) {
            if (isValid(g, row, col, num)) {
                g[row][col] = num;
                backtrack(g);
                g[row][col] = 0; // Backtrack
                if (solutions.length >= 2) return;
            }
        }
    }

    backtrack(grid);

    return {
        solutionsCount: solutions.length,
        solution: solutions.length > 0 ? solutions[0] : null,
        hasUniqueSolution: solutions.length === 1
    };
}

/**
 * Comprueba si un tablero inicial dado es resoluble (al menos una solución).
 * @param {string|Array} boardInput 
 * @returns {boolean}
 */
export function isSolvable(boardInput) {
    const result = solveSudoku(boardInput);
    return result.solutionsCount > 0;
}

/**
 * Comprueba estrictamente si un tablero tiene una y solo una solución única.
 * @param {string|Array} boardInput 
 * @returns {boolean}
 */
export function hasUniqueSolution(boardInput) {
    const result = solveSudoku(boardInput);
    return result.hasUniqueSolution;
}