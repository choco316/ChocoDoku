/**
 * ChocoDoku - exporter.js
 * Módulo de exportación editorial (JSON y CSV) para volúmenes, puzzles, soluciones y manifiestos.
 */

import { getActiveMaster } from './data-manager.js';
import { getFilteredRecords } from './reviewer.js';

/**
 * Obtiene los registros objetivo según el alcance seleccionado.
 * @param {string} scope - 'filtered' o 'all'
 * @returns {Array} Registros a exportar.
 */
function getRecordsByScope(scope) {
    if (scope === 'filtered') {
        return getFilteredRecords();
    } else {
        const master = getActiveMaster();
        return master.records || [];
    }
}

/**
 * Convierte un arreglo de registros en una cadena CSV tabulada.
 * @param {Array} records 
 * @param {string} type - 'puzzles', 'solutions', 'both', 'manifest'
 * @returns {string} Contenido CSV.
 */
function recordsToCSV(records, type) {
    let headers = [];
    let rows = [];

    if (type === 'puzzles') {
        headers = ['ID', 'CollectionId', 'VolumeId', 'Difficulty', 'Status', 'Puzzle'];
        rows = records.map(r => [r.id, r.collectionId, r.volumeId, r.difficulty, r.status, `"${r.puzzle}"`]);
    } else if (type === 'solutions') {
        headers = ['ID', 'CollectionId', 'VolumeId', 'Difficulty', 'Status', 'Solution'];
        rows = records.map(r => [r.id, r.collectionId, r.volumeId, r.difficulty, r.status, `"${r.solution}"`]);
    } else if (type === 'both') {
        headers = ['ID', 'CollectionId', 'VolumeId', 'Difficulty', 'Status', 'Puzzle', 'Solution'];
        rows = records.map(r => [r.id, r.collectionId, r.volumeId, r.difficulty, r.status, `"${r.puzzle}"`, `"${r.solution}"`]);
    } else if (type === 'manifest') {
        headers = ['ID', 'CollectionId', 'VolumeId', 'Difficulty', 'Status', 'CreatedAt', 'MaxComplexity', 'TechniquesUsed'];
        rows = records.map(r => [
            r.id,
            r.collectionId,
            r.volumeId,
            r.difficulty,
            r.status,
            r.createdAt,
            r.difficultyAnalysis?.maxComplexity || 'N/A',
            `"${(r.difficultyAnalysis?.techniquesUsed || []).join(', ')}"`
        ]);
    }

    const csvContent = [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    return csvContent;
}

/**
 * Genera el archivo descargable (Blob) según el formato y alcance solicitados.
 * @param {string} format - 'json', 'csv-puzzles', 'csv-solutions', 'csv-both', 'manifest'
 * @param {string} scope - 'filtered' o 'all'
 * @returns {Object} { blob: Blob, filename: string, count: number }
 */
export function generateExportFile(format, scope = 'filtered') {
    const records = getRecordsByScope(scope);
    const master = getActiveMaster();
    const volumeIdClean = master.volumeId.replace(/\s+/g, '_');
    
    let blob;
    let filename = '';
    let count = records.length;

    if (format === 'json') {
        const exportObj = {
            ...master,
            records: records // Exporta solo los registros según el alcance
        };
        const jsonStr = JSON.stringify(exportObj, null, 2);
        blob = new Blob([jsonStr], { type: 'application/json' });
        filename = `ChocoDoku_${volumeIdClean}_Master.json`;
    } else {
        let csvType = 'puzzles';
        let suffix = 'Puzzles';
        
        if (format === 'csv-puzzles') {
            csvType = 'puzzles';
            suffix = 'Puzzles';
        } else if (format === 'csv-solutions') {
            csvType = 'solutions';
            suffix = 'Solutions';
        } else if (format === 'csv-both') {
            csvType = 'both';
            suffix = 'Puzzles_and_Solutions';
        } else if (format === 'manifest') {
            csvType = 'manifest';
            suffix = 'Editorial_Manifest';
        }

        const csvString = recordsToCSV(records, csvType);
        blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
        filename = `ChocoDoku_${volumeIdClean}_${suffix}.csv`;
    }

    return {
        blob,
        filename,
        count
    };
}